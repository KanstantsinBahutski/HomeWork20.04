public class Main {
    public static void main(String[] args) {
        String text = StringRandom.generateText(1000);
        System.out.println(text);
    }
}